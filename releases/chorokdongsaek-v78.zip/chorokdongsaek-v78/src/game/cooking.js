// 조리실의 요리법과 요리. 공작소(crafting.js)와 완전히 같은 구조이지만 별도의 재료·결과물 체계를 쓴다.
// 레시피는 아직 없다(곧 채워 넣을 예정) — COOK_RECIPES 를 채우기만 하면 조리실 화면에 그대로 나타난다.
//  - player.cookRecipes = { [recipeId]: true }  (익힌 요리법)
//  - 관리자는 모든 요리법을 아는 것으로 친다.
import { countOf, itemOf } from './items'

export const KITCHEN = {
  id: 'kitchen',
  name: '조리실',
  desc: '가스불과 커다란 조리대, 각종 식자재가 갖춰진 공간. 이곳에서 식재료를 조합해서 음식을 만들 수 있다.',
}

// inputs: [아이템 id, 개수]. result: 만들어지는 아이템 id (qty 기본 1)
export const COOK_RECIPES = []

export const cookRecipeOf = (id) => COOK_RECIPES.find((r) => r.id === id)
export const knowsCookRecipe = (player, id, admin = false) => admin || !!player.cookRecipes?.[id]

/** 요리법 익히기 (이미 알면 같은 player) */
export function learnCookRecipe(player, id) {
  if (!cookRecipeOf(id) || player.cookRecipes?.[id]) return player
  return { ...player, cookRecipes: { ...(player.cookRecipes ?? {}), [id]: true } }
}
export const canCook = (player, r) => r.inputs.every(([id, n]) => countOf(player, id) >= n)

/** 조리: 요리법을 모르면 { error }. 관리자는 재료를 쓰지 않는다. 성공하면 { player, item } */
export function cook(player, recipeId, admin = false) {
  const r = cookRecipeOf(recipeId)
  if (!r) return { error: '그런 요리법은 없다.' }
  if (!knowsCookRecipe(player, recipeId, admin)) return { error: '요리법을 모른다. 요리법이 없으면 아무것도 만들 수 없다.' }
  if (!admin && !canCook(player, r)) return { error: '재료가 모자란다.' }
  const inv = { ...(player.inventory ?? {}) }
  if (!admin) {
    for (const [id, n] of r.inputs) {
      inv[id] -= n
      if (inv[id] <= 0) delete inv[id]
    }
  }
  inv[r.result] = (inv[r.result] || 0) + 1
  return { player: { ...player, inventory: inv }, item: itemOf(r.result) }
}
